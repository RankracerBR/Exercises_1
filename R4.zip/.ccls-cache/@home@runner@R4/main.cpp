#include <iostream>
using namespace::std;
int main() {
cout << "Conversão de fahrenheint em Celsius!\n";
cout <<"100 gráus em fahrenheint em Celsius equivalem a: "; 
cout << (100 - 32) / (9) * 5;
cout << "C*";
}