#include <iostream>
using namespace::std;
int main() {
cout << "Cáculo do IMC de Fulano: ";
cout << 70/1.75*1.75;

  }