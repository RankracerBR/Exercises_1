#include <iostream>

int main() {
using namespace::std; 
cout << "Augusto Pontes\n";
}