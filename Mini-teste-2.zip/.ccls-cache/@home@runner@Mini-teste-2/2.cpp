#include <iostream>

using namespace::std;

int main() {

cout << "*******************\n";
cout << " *  Bem-vindo  *\n";
cout << "*******************\n";

}
  