#include <iostream>
using namespace::std;

int main() {
cout << (3*6)/(2+4) + 2;
}